package hw_02_01_operators;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HW_02_01_03
{
	public static void main(String[] args) throws IOException
	{
		int x, y, z;
		System.out.println("enter x: ");
		x = getN();
		System.out.println("enter y: ");
		y = getN();
		System.out.println("enter z: ");
		z = getN();

		System.out.println(getSum(x, z, y));

	}

	public static int getN() throws IOException
	{

		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

		int n = Integer.parseInt(bufferedReader.readLine());

		return n;

	}

	public static int getSum(int a, int b, int c)
	{
		int sum = 0;

		if (a >= 0)
			sum += a;
		if (b >= 0)
			sum += b;
		if (c >= 0)
			sum += c;

		return sum;
	}

}
