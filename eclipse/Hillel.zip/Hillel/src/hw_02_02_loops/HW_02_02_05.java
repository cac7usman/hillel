package hw_02_02_loops;
/*
 * Посчитать сумму цифр заданного числа
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HW_02_02_05
{
	public static void main(String[] args) throws IOException
	{

		int result = getSum(getN());
		System.out.println(result);

	}

	public static int getN() throws IOException
	{

		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

		int x = Integer.parseInt(bufferedReader.readLine());

		return x;

	}

	public static int getSum(int x)
	{
		String s = String.valueOf(x);
		String[] array = s.split("");

		int sum = 0;
		for (String string : array)
		{
			sum += Integer.parseInt(string);
		}

		return sum;
	}
}
